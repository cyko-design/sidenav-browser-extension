# Custom Nav for Chrome

Custom Nav adds an optional left navigation sidebar to websites you choose. It inherits site typography, detects the tab’s colours per page, and keeps the site’s own menus available.

## Install

1. If you downloaded the ZIP, unzip it first.
2. Open `chrome://extensions` in Chrome and turn on **Developer mode**.
3. Click **Load unpacked**, then select the **extension** folder containing `manifest.json`.
4. Open or reload [Higgsfield](https://higgsfield.ai/). From Chrome’s Extensions menu, open **Custom Nav** and switch **Enhanced Navigation** on under **Higgsfield**. Pin Custom Nav if you want its settings one click away.
5. Click or tap the tab on the left edge of Higgsfield to open the sidebar. Drag the tab up or down to reposition it. With the tab focused, use the up and down arrow keys to move it, or Enter or Space to open the sidebar. Custom Nav saves the tab position for Higgsfield. The Higgsfield logo links home. Use the close button, Escape while focused inside the sidebar, or click outside to dismiss it.
6. Click or tap a section with an arrow to show its sublinks. With the keyboard, use Enter or Space. Opening another section closes the previous submenu. The first item is the section’s home link, marked with Higgsfield’s Home icon.

**Enhanced Navigation** turns the edge tab and sidebar on or off for Higgsfield. The panel scrolls independently and fits the viewport.

The drag tab follows the site’s native theme. It uses the site’s accent and surface colours when they contrast, or a readable pair from the site’s own CSS.

## Use on another website

1. Open the site, then choose **Allow Site Access** in Custom Nav and approve access to that hostname in Chrome. Custom Nav turns on **Enhanced Navigation** and starts one scan of that page. If Chrome closes the popup after approval, reopen it for the review.
2. Review the links and choose **Save Links** or **Discard**. Use **Scan Navigation** to find new links later.
3. Use **Remove Site Access** to disconnect that website. The extension stops running there and retains that website’s saved links and settings for a future reconnect. Use **Clear Saved Navigation** to remove those links.

Each HTTP or HTTPS origin on a standard port keeps its own settings, saved links, and scan timestamp. Higgsfield retains its bundled adapter and existing settings. Chrome’s internal pages and other restricted destinations cannot use the sidebar.

Generic scans check navigation landmarks, rendered dropdowns and responsive menus in the active page. Same-origin feature links with conventional paths can be saved. Known personal and account routes, opaque IDs, external links and non-tracking query parameters are excluded. A generic scan can read a hidden menu already present in the markup. If a site creates its menu only after opening it, the menu needs to stay open for the scan or the site needs an adapter. Review results before saving because websites can use different conventions for private routes.

On single-page apps, the saved sidebar stays available during route changes and follows the current route. Scan manually on the new page to review any additional links.

If Higgsfield was already open before installing or reloading the extension, refresh that tab once. Keep the unpacked folder in place while using the extension.

To update an existing installation, replace the files in the same unpacked folder, click **Reload** on the Custom Nav card in `chrome://extensions`, and refresh Higgsfield. Your settings are kept.

## Scope and storage

The extension uses the reviewed desktop navigation from November 15, 2026. It includes 21 top-level destinations and publicly exposed child links. Cinema Studio’s Projects shortcut opens the studio and focuses the native Search projects control when it is visible. Community’s public Projects gallery has its own direct link. Sign-in and sign-up remain in the site's own UI. The API link goes to Higgsfield’s API domain, where the extension does not inject a sidebar.

To discover feature links, open a Higgsfield page and choose **Scan Navigation** from the extension popup. Chrome must allow Custom Nav to access that tab. You can use your existing Higgsfield session when scanning feature menus available only after signing in. The scan checks supported navigation menus on the current page. It does not visit other pages, open content collections, or collect projects, files, assets, chats, or account details.

**Last Scanned** updates after a completed scan, including when it finds no new links. Review the proposed additions grouped by section, then choose **Save Links** or **Discard**. Discarding keeps the existing links. Custom Nav stores approved links and preferences locally. After the first scan started by **Allow Site Access**, scans run only when you choose **Scan Navigation**. **Clear Saved Navigation** is available when there are saved scan links and removes those links and the timestamp after confirmation. Higgsfield’s bundled links remain available.

## Extending to other sites

- `sites/higgsfield.js` defines the Higgsfield adapter. `sites/website.js` creates one configuration per other allowed origin.
- `website-scan.js` reads generic navigation markup. `website-links.js` validates, deduplicates, and groups the links.
- `background.js` registers and removes site-scoped content scripts as permissions change. Scanning remains an explicit popup action.
- `navigation.js` loads the bundled catalog and applies approved additions from local storage.
- `discovery.js` validates static feature routes and merges approved additions under their parent sections. `scan-page.js` reads the site adapter’s allowed menus in response to a popup scan request.
- `sidebar.js` renders navigation and handles keyboard, resize, and preference changes.
