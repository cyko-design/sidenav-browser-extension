const siteList = document.getElementById("sites");
const template = document.getElementById("site-settings");

chrome.tabs.query({ active: true, currentWindow: true }).then(([tab]) => {
  const site = siteForUrl(tab?.url);
  if (site && Number.isInteger(tab.id)) renderSite(site, tab.id);
  else siteList.textContent = "Open the website you want to use with Custom Nav.";
}).catch(() => { siteList.textContent = "Couldn’t identify the current tab."; });

function renderSite(site, tabId) {
  const section = template.content.firstElementChild.cloneNode(true);
  section.querySelector(".site-name").textContent = site.name;
  section.querySelector(".confirm-site").textContent = site.name;

  const enabled = section.querySelector('[role="switch"]');
  const description = section.querySelector(".setting-description");
  description.id = `enhanced-navigation-description-${site.id}`;
  enabled.setAttribute("aria-describedby", description.id);
  const clear = section.querySelector(".clear");
  const confirmation = section.querySelector(".confirmation");
  const cancel = section.querySelector(".cancel");
  const confirm = section.querySelector(".confirm");
  const timestamp = section.querySelector(".timestamp");
  const status = section.querySelector(".status");
  const cacheKey = navigationKey(site);
  const timeKey = scanTimeKey(site);
  const setupKey = siteSetupKey(site);
  const enabledKey = settingsKey(site, "enabled");
  const scan = section.querySelector(".scan");
  const scanHint = section.querySelector(".scan-hint");
  const review = section.querySelector(".review");
  const reviewList = section.querySelector(".review-list");
  const discard = section.querySelector(".discard");
  const save = section.querySelector(".save");
  const accessRow = section.querySelector(".access-row");
  const access = section.querySelector(".site-access");
  const builtInNote = section.querySelector(".built-in-note");
  builtInNote.hidden = site.generic === true;
  let settings;
  let connected = !site.generic;
  let updatingEnabled = false;
  let updatingAccess = site.generic === true;
  let scanning = false;
  let hasSavedLinks = false;
  let setup;
  let reviewFromSetup = false;
  let preparation;
  let pending = [];
  const lockName = navigationLockName(site);

  function showStatus(message) {
    status.textContent = message;
    status.hidden = !message;
  }

  watchSettings(site, value => {
    settings = value;
    enabled.checked = settings.enabled;
    updateSwitchAvailability();
  }, () => showStatus("Couldn’t load settings. Reopen Custom Nav to try again."));

  enabled.addEventListener("change", async () => {
    showStatus("");
    const turnOn = enabled.checked;
    updatingEnabled = true;
    updateSwitchAvailability();
    try {
      if (turnOn && site.generic) await prepareCurrentTab();
      await chrome.storage.local.set({ [enabledKey]: turnOn });
    } catch {
      enabled.checked = settings.enabled;
      showStatus("Couldn’t update navigation on this tab. Try reopening Custom Nav.");
    } finally {
      updatingEnabled = false;
      updateSwitchAvailability();
    }
  });

  function renderLastScan(value) {
    const date = value == null ? null : new Date(value);
    timestamp.textContent = date && Number.isFinite(date.getTime()) ? date.toLocaleString() : "Never";
  }

  function renderSavedLinks(record) {
    hasSavedLinks = ["reviewed", "website"].includes(record?.source) && record.discoveries?.length > 0;
    updateActions();
  }

  function renderSetup(value) {
    setup = value;
    if (!value && reviewFromSetup) {
      reviewFromSetup = false;
      closeReview();
    }
    if (value?.state === "scanning") showStatus("Scanning feature navigation…");
    if (value?.state === "review") {
      pending = validatedWebsiteLinks(site, value.links);
      reviewFromSetup = pending.length > 0;
      if (reviewFromSetup) showReview();
    }
    if (value?.state === "done") {
      showStatus(value.message);
      chrome.storage.session.remove(setupKey).catch(() => {});
    }
    updateActions();
  }

  const changedKeys = new Set();
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local") {
      if (Object.hasOwn(changes, timeKey)) {
        changedKeys.add(timeKey);
        renderLastScan(changes[timeKey].newValue);
      }
      if (Object.hasOwn(changes, cacheKey)) {
        changedKeys.add(cacheKey);
        renderSavedLinks(changes[cacheKey].newValue);
      }
    } else if (area === "session" && site.generic && Object.hasOwn(changes, setupKey)) {
      changedKeys.add(setupKey);
      renderSetup(changes[setupKey].newValue);
    }
  });
  chrome.storage.local.get([timeKey, cacheKey]).then(saved => {
    if (!changedKeys.has(timeKey)) renderLastScan(saved[timeKey]);
    if (!changedKeys.has(cacheKey)) renderSavedLinks(saved[cacheKey]);
  }).catch(() => showStatus("Couldn’t load saved navigation."));
  if (site.generic) {
    chrome.storage.session.get(setupKey).then(saved => {
      if (!changedKeys.has(setupKey)) renderSetup(saved[setupKey]);
    }).catch(() => showStatus("Couldn’t load the first scan results."));
  }

  function updateActions() {
    const settingUp = setup?.state === "scanning"
      || (connected && setup?.state === "awaiting" && setup.expiresAt > Date.now());
    const busy = scanning || updatingAccess || settingUp || !review.hidden || !confirmation.hidden;
    scan.disabled = !connected || busy;
    clear.disabled = !hasSavedLinks || busy;
    access.disabled = busy;
  }

  function setAccess(value) {
    connected = value;
    updateSwitchAvailability();
    updateActions();
    scanHint.hidden = connected;
    scanHint.textContent = "Allow site access to scan.";
    access.textContent = connected ? "Remove Site Access" : "Allow Site Access";
  }

  function updateSwitchAvailability() {
    enabled.disabled = !connected || !settings || updatingEnabled;
  }

  function prepareCurrentTab() {
    if (!preparation) {
      preparation = chrome.runtime.sendMessage({ type: "prepare-site", site: site.id, tabId })
        .then(result => {
          if (!result?.connected || !result.documentId) throw new Error("Couldn’t prepare this page.");
          return result.documentId;
        }).finally(() => { preparation = undefined; });
    }
    return preparation;
  }

  if (site.generic) {
    accessRow.hidden = false;
    const permission = { origins: [site.match] };
    setAccess(false);
    chrome.permissions.contains(permission).then(granted => {
      setAccess(granted);
      if (granted) prepareCurrentTab().catch(() => showStatus("Access granted. This page couldn’t be prepared. Try scanning again."));
    })
      .catch(() => showStatus("Couldn’t check this site’s access."))
      .finally(() => {
        updatingAccess = false;
        updateActions();
      });
    access.addEventListener("click", async () => {
      updatingAccess = true;
      updateActions();
      showStatus("");
      try {
        if (connected) {
          const result = await chrome.runtime.sendMessage({ type: "disconnect-site", site: site.id });
          if (result?.connected !== false) throw new Error("Couldn’t remove site access.");
          setAccess(false);
          showStatus("Site access removed.");
        } else {
          // Start the worker request and open Chrome’s prompt in the same click.
          // The worker and its scan results survive Chrome dismissing this popup.
          const setupRequest = chrome.runtime.sendMessage({ type: "scan-on-grant", site: site.id, tabId })
            .catch(() => ({ error: true }));
          const granted = await chrome.permissions.request(permission);
          if (!granted) {
            await setupRequest;
            await chrome.runtime.sendMessage({ type: "cancel-site-setup", site: site.id });
            showStatus("Site access wasn’t granted.");
            return;
          }
          setAccess(true);
          const requested = await setupRequest;
          if (requested?.requested !== true) throw new Error("Couldn’t start the first scan.");
        }
      } catch {
        showStatus("Couldn’t update site access. Reopen Custom Nav and try again.");
      } finally {
        updatingAccess = false;
        updateActions();
      }
    });
  } else {
    setAccess(true);
  }

  scan.addEventListener("click", async () => {
    scanning = true;
    updateActions();
    showStatus("Scanning feature navigation…");
    try {
      const target = site.generic ? { documentId: await prepareCurrentTab() } : { frameId: 0 };
      const result = await chrome.tabs.sendMessage(tabId, {
        type: "scan-navigation",
        site: site.id
      }, target);
      if (result?.error || !result?.inspected) {
        showStatus(result?.error ?? "No supported feature menu found. Try a page with the site’s main navigation.");
        return;
      }
      const scannedAt = new Date().toISOString();
      await navigator.locks.request(lockName, () => chrome.storage.local.set({ [timeKey]: scannedAt }));
      if (site.generic) pending = newWebsiteLinks(site, await readSavedLinks(site), result.results);
      else pending = additionsToNavigation(site, await loadNavigation(site), result.results);
      if (pending.length) showReview();
      else showStatus("No new feature links found on this page.");
    } catch {
      showStatus(site.generic
        ? "Couldn’t scan this tab. Check that you’re still on this site and try again."
        : "Couldn’t scan this tab. Refresh the page and check that Custom Nav has site access.");
    } finally {
      scanning = false;
      updateActions();
    }
  });

  function showReview() {
    reviewList.replaceChildren();
    for (const parent of new Set(pending.map(entry => entry.parent ?? "Main navigation"))) {
      const heading = document.createElement("h4");
      heading.textContent = parent;
      const links = document.createElement("ul");
      for (const entry of pending.filter(link => (link.parent ?? "Main navigation") === parent)) {
        const row = document.createElement("li");
        const url = new URL(entry.href);
        const path = document.createElement("small");
        path.textContent = url.pathname + url.search + url.hash;
        row.append(entry.label, path);
        links.append(row);
      }
      reviewList.append(heading, links);
    }
    showStatus("");
    review.hidden = false;
    updateActions();
    discard.focus();
  }

  function closeReview() {
    if (reviewFromSetup) chrome.storage.session.remove(setupKey).catch(() => {});
    reviewFromSetup = false;
    pending = [];
    review.hidden = true;
    updateActions();
    scan.focus();
  }

  discard.addEventListener("click", closeReview);
  save.addEventListener("click", async () => {
    save.disabled = true;
    discard.disabled = true;
    try {
      await navigator.locks.request(lockName, async () => {
        const prior = await readSavedLinks(site);
        const discoveries = site.generic ? [...prior, ...newWebsiteLinks(site, prior, pending)]
          : additionsToNavigation(site, normalizeItems(site, site.items), [...prior, ...pending]);
        await chrome.storage.local.set({
          [cacheKey]: { schema: 3, source: site.generic ? "website" : "reviewed", discoveries }
        });
      });
      closeReview();
      showStatus("Links saved.");
    } catch {
      showStatus("Couldn’t save the links. Try again.");
    } finally {
      save.disabled = false;
      discard.disabled = false;
    }
  });

  function closeConfirmation() {
    confirmation.hidden = true;
    updateActions();
    (clear.disabled ? scan : clear).focus();
  }

  clear.addEventListener("click", () => {
    showStatus("");
    confirmation.hidden = false;
    updateActions();
    cancel.focus();
  });
  cancel.addEventListener("click", closeConfirmation);
  confirm.addEventListener("click", async () => {
    confirm.disabled = true;
    cancel.disabled = true;
    try {
      const result = await chrome.runtime.sendMessage({ type: "clear-navigation", site: site.id });
      if (!Number.isInteger(result?.removed)) throw new Error("The clear was not verified.");
      const { removed } = result;
      const summary = removed
        ? `Cleared ${removed} scanned ${removed === 1 ? "link" : "links"}.`
        : "There were no saved scanned links to clear.";
      showStatus(summary + (site.generic ? "" : " Built-in links stay in the sidebar."));
    } catch {
      showStatus("Couldn’t clear saved navigation. Try again.");
    } finally {
      confirm.disabled = false;
      cancel.disabled = false;
      closeConfirmation();
    }
  });

  siteList.append(section);
}
