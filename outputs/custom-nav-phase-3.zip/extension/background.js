importScripts("sites/higgsfield.js", "sites/website.js", "website-links.js", "navigation.js", "discovery.js");

chrome.runtime.onMessage.addListener((message, sender, reply) => {
  if (sender.id !== chrome.runtime.id || sender.url !== chrome.runtime.getURL("popup.html")) return;
  const site = siteForId(message?.site);
  if (!site) return;

  let work;
  switch (message.type) {
    case "clear-navigation":
      work = () => clearNavigation(site);
      break;
    case "prepare-site":
      if (site.generic && Number.isInteger(message.tabId)) work = () => prepareSite(site, message.tabId);
      break;
    case "scan-on-grant":
      if (site.generic && Number.isInteger(message.tabId)) work = () => startSiteSetup(site, message.tabId);
      break;
    case "cancel-site-setup":
      if (site.generic) work = () => chrome.storage.session.remove(siteSetupKey(site)).then(() => ({}));
      break;
    case "disconnect-site":
      if (site.generic) work = () => disconnectSite(site);
      break;
  }
  if (!work) return;
  navigator.locks.request(navigationLockName(site), work).then(reply, () => reply({ error: true }));
  return true;
});

async function clearNavigation(site) {
  const keys = [navigationKey(site), scanTimeKey(site)];
  const links = await readSavedLinks(site);
  await chrome.storage.local.remove(keys);
  const remaining = await chrome.storage.local.get(keys);
  if (keys.some(key => Object.hasOwn(remaining, key))) throw new Error("Saved navigation is still present.");
  return { removed: links.length };
}

async function prepareSite(site, tabId) {
  const tab = await chrome.tabs.get(tabId);
  if (siteForUrl(tab.url)?.id !== site.id || !await chrome.permissions.contains({ origins: [site.match] })) {
    throw new Error("Site access is unavailable.");
  }
  await registerSite(site);

  const [probe] = await chrome.scripting.executeScript({
    target: { tabId },
    func: () => ({
      origin: location.origin,
      ready: globalThis.customNavReceiverReady === true && globalThis.customNavSidebarReady === true
    })
  });
  if (probe?.result?.origin !== new URL(site.home).origin || !probe.documentId) {
    throw new Error("The page changed before Custom Nav could load.");
  }
  if (!probe.result.ready) {
    const target = { tabId, documentIds: [probe.documentId] };
    const [script] = chrome.runtime.getManifest().content_scripts;
    await chrome.scripting.insertCSS({ target, files: script.css });
    await chrome.scripting.executeScript({ target, files: script.js });
  }
  return { connected: true, documentId: probe.documentId };
}

async function startSiteSetup(site, tabId) {
  const tab = await chrome.tabs.get(tabId);
  if (siteForUrl(tab.url)?.id !== site.id) throw new Error("The tab has changed websites.");
  await chrome.storage.session.set({
    [siteSetupKey(site)]: { state: "awaiting", tabId, expiresAt: Date.now() + 120_000 }
  });
  // Approval and the popup's setup message can reach the worker in either order.
  if (await chrome.permissions.contains({ origins: [site.match] })) await finishSiteSetup(site);
  return { requested: true };
}

async function finishSiteSetup(site) {
  const key = siteSetupKey(site);
  const setup = (await chrome.storage.session.get(key))[key];
  if (setup?.state !== "awaiting") return;
  if (setup.expiresAt < Date.now()) {
    await chrome.storage.session.remove(key);
    return;
  }
  await chrome.storage.session.set({ [key]: { state: "scanning" } });
  // Switch on the launcher even if no approved links have been saved yet.
  await chrome.storage.local.set({ [settingsKey(site, "enabled")]: true });
  let outcome;
  try {
    const { documentId } = await prepareSite(site, setup.tabId);
    const response = await chrome.tabs.sendMessage(setup.tabId, {
      type: "scan-navigation", site: site.id
    }, { documentId });
    if (response?.error || !response?.inspected) {
      outcome = { state: "done", message: response?.error ?? "No supported navigation found on this page." };
    } else {
      await chrome.storage.local.set({ [scanTimeKey(site)]: new Date().toISOString() });
      const links = newWebsiteLinks(site, await readSavedLinks(site), response.results);
      outcome = links.length ? { state: "review", links }
        : { state: "done", message: "No new feature links found on this page." };
    }
  } catch {
    outcome = { state: "done", message: "Navigation is on. The first scan couldn’t finish. Try Scan Navigation." };
  }
  await chrome.storage.session.set({ [key]: outcome });
}

async function registerSite(site, update = false) {
  const [script] = chrome.runtime.getManifest().content_scripts;
  const id = siteScriptId(site);
  const registration = { id, matches: [site.match], js: script.js, css: script.css, runAt: script.run_at };
  const registered = await chrome.scripting.getRegisteredContentScripts({ ids: [id] });
  if (!registered.length) await chrome.scripting.registerContentScripts([{ ...registration, persistAcrossSessions: true }]);
  else if (update) await chrome.scripting.updateContentScripts([registration]);
  const key = siteAccessKey(site);
  if ((await chrome.storage.local.get(key))[key] !== true) await chrome.storage.local.set({ [key]: true });
}

async function disconnectSite(site) {
  const permission = { origins: [site.match] };
  if (await chrome.permissions.contains(permission) && !await chrome.permissions.remove(permission)) {
    throw new Error("Couldn’t remove site permission.");
  }
  await removeRegistration(site);
  return { connected: false };
}

async function removeRegistration(site) {
  await chrome.storage.session.remove(siteSetupKey(site));
  await chrome.storage.local.remove(siteAccessKey(site));
  const id = siteScriptId(site);
  if ((await chrome.scripting.getRegisteredContentScripts({ ids: [id] })).length) {
    await chrome.scripting.unregisterContentScripts({ ids: [id] });
  }
}

chrome.permissions.onRemoved.addListener(({ origins = [] }) => {
  for (const origin of origins) {
    const site = siteForUrl(origin);
    if (!site?.generic) continue;
    navigator.locks.request(navigationLockName(site), async () => {
      if (!await chrome.permissions.contains({ origins: [site.match] })) await removeRegistration(site);
    }).catch(error => console.warn("Custom Nav site access:", error));
  }
});

// Chrome may close the popup while showing its permission prompt.
chrome.permissions.onAdded.addListener(({ origins = [] }) => {
  registerGrantedOrigins(origins).catch(error => console.warn("Custom Nav site access:", error));
});

chrome.runtime.onInstalled.addListener(({ reason }) => {
  if (reason !== "update") return;
  restoreSiteRegistrations().catch(error => console.warn("Custom Nav site access:", error));
});

async function restoreSiteRegistrations() {
  const { origins = [] } = await chrome.permissions.getAll();
  await registerGrantedOrigins(origins, true);
}

async function registerGrantedOrigins(origins, update = false) {
  for (const origin of origins) {
    const site = siteForUrl(origin);
    if (!site?.generic || site.match !== origin) continue;
    await navigator.locks.request(navigationLockName(site), async () => {
      if (!await chrome.permissions.contains({ origins: [site.match] })) return;
      await registerSite(site, update);
      if (!update) await finishSiteSetup(site);
    });
  }
}
