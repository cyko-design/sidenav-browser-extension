function siteForUrl(value) {
  let url;
  try {
    url = new URL(value);
  } catch {
    return;
  }
  if (!["http:", "https:"].includes(url.protocol) || url.port || url.username || url.password
      || !/^[a-z0-9.-]+$/i.test(url.hostname)) return;

  const adapter = customNavSites.find(site => url.protocol === "https:" && site.hosts.includes(url.hostname));
  if (adapter) return adapter;
  return {
    id: `web:${url.origin}`,
    name: url.hostname,
    home: `${url.origin}/`,
    hosts: [url.hostname],
    match: `${url.origin}/*`,
    generic: true
  };
}

function siteForId(id) {
  if (typeof id !== "string") return;
  if (id.startsWith("web:")) {
    const site = siteForUrl(id.slice(4));
    if (site?.id === id) return site;
  } else {
    return customNavSites.find(site => site.id === id);
  }
}

function siteAccessKey(site) {
  return `access:${site.id}`;
}

function siteSetupKey(site) {
  return `setup:${site.id}`;
}

function siteScriptId(site) {
  return "site-" + btoa(site.id).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}
