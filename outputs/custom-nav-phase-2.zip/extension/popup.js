const siteList = document.getElementById("sites");
const template = document.getElementById("site-settings");

for (const site of navSites) {
  const section = template.content.firstElementChild.cloneNode(true);
  section.querySelector(".site-name").textContent = site.name;
  section.querySelector(".confirm-site").textContent = site.name;

  const enabled = section.querySelector('[role="switch"]');
  const description = section.querySelector(".setting-description");
  description.id = `enhanced-navigation-description-${site.id}`;
  enabled.setAttribute("aria-describedby", description.id);
  const clear = section.querySelector(".clear");
  const confirmation = section.querySelector(".confirmation");
  const cancel = section.querySelector(".cancel");
  const confirm = section.querySelector(".confirm");
  const timestamp = section.querySelector(".timestamp");
  const status = section.querySelector(".status");
  const cacheKey = navigationKey(site);
  const timeKey = scanTimeKey(site);
  const enabledKey = settingsKey(site, "enabled");
  const scan = section.querySelector(".scan");
  const scanHint = section.querySelector(".scan-hint");
  const review = section.querySelector(".review");
  const reviewList = section.querySelector(".review-list");
  const discard = section.querySelector(".discard");
  const save = section.querySelector(".save");
  let settings;
  let tabId;
  let pending = [];
  const lockName = navigationLockName(site);

  function showStatus(message) {
    status.textContent = message;
    status.hidden = !message;
  }

  watchSettings(site, value => {
    settings = value;
    enabled.checked = settings.enabled;
    enabled.disabled = false;
  }, () => showStatus("Couldn’t load settings. Reopen Custom Nav to try again."));

  enabled.addEventListener("change", async () => {
    showStatus("");
    try {
      await chrome.storage.local.set({ [enabledKey]: enabled.checked });
    } catch {
      enabled.checked = settings.enabled;
      showStatus("Couldn’t save this setting. Try again.");
    }
  });

  function renderLastScan(value) {
    const date = value == null ? null : new Date(value);
    timestamp.textContent = date && Number.isFinite(date.getTime()) ? date.toLocaleString() : "Never";
  }

  let receivedTimeUpdate = false;
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local" || !Object.hasOwn(changes, timeKey)) return;
    receivedTimeUpdate = true;
    renderLastScan(changes[timeKey].newValue);
  });
  chrome.storage.local.get(timeKey).then(saved => {
    if (!receivedTimeUpdate) renderLastScan(saved[timeKey]);
  }).catch(() => showStatus("Couldn’t load the last scan."));

  chrome.tabs.query({ active: true, currentWindow: true }).then(([tab]) => {
    const url = tab?.url && new URL(tab.url);
    if (tab?.id != null && url?.protocol === "https:" && site.hosts.includes(url.hostname)) {
      tabId = tab.id;
      scan.disabled = !confirmation.hidden;
    } else {
      scanHint.textContent = `Open ${site.name} with site access to scan.`;
      scanHint.hidden = false;
    }
  }).catch(() => showStatus("Couldn’t identify the current tab."));

  scan.addEventListener("click", async () => {
    scan.disabled = true;
    clear.disabled = true;
    showStatus("Scanning feature navigation…");
    try {
      const result = await chrome.tabs.sendMessage(tabId, {
        type: "scan-navigation",
        site: site.id
      }, { frameId: 0 });
      if (result?.error || !result?.inspected) {
        showStatus(result?.error ?? "No supported feature menu found on this page. Try the homepage or a studio page.");
        return;
      }
      const scannedAt = new Date().toISOString();
      await navigator.locks.request(lockName, () => chrome.storage.local.set({ [timeKey]: scannedAt }));
      const items = await loadNavigation(site);
      pending = additionsToNavigation(site, items, result.results);
      if (pending.length) showReview();
      else showStatus("No new feature links found on this page.");
    } catch {
      showStatus("Couldn’t scan this tab. Refresh the page and check that Custom Nav has site access.");
    } finally {
      scan.disabled = pending.length > 0;
      clear.disabled = pending.length > 0;
    }
  });

  function showReview() {
    reviewList.replaceChildren();
    for (const parent of new Set(pending.map(entry => entry.parent))) {
      const heading = document.createElement("h4");
      heading.textContent = parent;
      const links = document.createElement("ul");
      for (const entry of pending.filter(link => link.parent === parent)) {
        const row = document.createElement("li");
        const url = new URL(entry.href);
        const path = document.createElement("small");
        path.textContent = url.pathname + url.search;
        row.append(entry.label, path);
        links.append(row);
      }
      reviewList.append(heading, links);
    }
    showStatus("");
    review.hidden = false;
    discard.focus();
  }

  function closeReview() {
    pending = [];
    review.hidden = true;
    scan.disabled = false;
    clear.disabled = false;
    scan.focus();
  }

  discard.addEventListener("click", closeReview);
  save.addEventListener("click", async () => {
    save.disabled = true;
    discard.disabled = true;
    try {
      await navigator.locks.request(lockName, async () => {
        const prior = await readSavedLinks(site);
        const bundled = normalizeItems(site, site.items);
        const discoveries = additionsToNavigation(site, bundled, [...prior, ...pending]);
        await chrome.storage.local.set({ [cacheKey]: { schema: 3, source: "reviewed", discoveries } });
      });
      closeReview();
      showStatus("Links saved.");
    } catch {
      showStatus("Couldn’t save the links. Try again.");
    } finally {
      save.disabled = false;
      discard.disabled = false;
    }
  });

  function closeConfirmation() {
    confirmation.hidden = true;
    scan.disabled = tabId == null;
    clear.focus();
  }

  clear.addEventListener("click", () => {
    showStatus("");
    scan.disabled = true;
    confirmation.hidden = false;
    cancel.focus();
  });
  cancel.addEventListener("click", closeConfirmation);
  confirm.addEventListener("click", async () => {
    confirm.disabled = true;
    cancel.disabled = true;
    clear.disabled = true;
    try {
      const result = await chrome.runtime.sendMessage({ type: "clear-navigation", site: site.id });
      if (!Number.isInteger(result?.removed)) throw new Error("The clear was not verified.");
      const { removed } = result;
      const summary = removed
        ? `Cleared ${removed} scanned ${removed === 1 ? "link" : "links"}.`
        : "There were no saved scanned links to clear.";
      showStatus(summary + " Built-in links stay in the sidebar.");
    } catch {
      showStatus("Couldn’t clear saved navigation. Try again.");
    } finally {
      confirm.disabled = false;
      cancel.disabled = false;
      clear.disabled = false;
      closeConfirmation();
    }
  });

  siteList.append(section);
}
