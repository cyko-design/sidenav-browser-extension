# Custom Nav for Chrome

Custom Nav adds an optional left navigation sidebar to Higgsfield. It uses the site's font, text and hover styles, and keeps the site's own menus available.

## Install

1. If you downloaded the ZIP, unzip it first.
2. Open `chrome://extensions` in Chrome and turn on **Developer mode**.
3. Click **Load unpacked**, then select the **extension** folder containing `manifest.json`.
4. Open or reload [Higgsfield](https://higgsfield.ai/). From Chrome’s Extensions menu, open **Custom Nav** and switch **Enhanced Navigation** on under **Higgsfield**. Pin Custom Nav if you want its settings one click away.
5. Click or tap the tab on the left edge of Higgsfield to open the sidebar. Drag the tab up or down to reposition it. With the tab focused, use the up and down arrow keys to move it, or Enter or Space to open the sidebar. Custom Nav saves the tab position for Higgsfield. The Higgsfield logo links home. Use the close button, Escape while focused inside the sidebar, or click outside to dismiss it.
6. Click or tap a section with an arrow to show its sublinks. With the keyboard, use Enter or Space. Opening another section closes the previous submenu. The first item is the section’s home link, marked with Higgsfield’s Home icon.

**Enhanced Navigation** turns the edge tab and sidebar on or off for Higgsfield. The panel scrolls independently and fits the viewport.

The drag tab follows the site’s native theme. It uses the site’s accent and surface colours when they contrast, or a readable pair from the site’s own CSS.

If Higgsfield was already open before installing or reloading the extension, refresh that tab once. Keep the unpacked folder in place while using the extension.

To update an existing installation, replace the files in the same unpacked folder, click **Reload** on the Custom Nav card in `chrome://extensions`, and refresh Higgsfield. Your settings are kept.

## Scope and storage

The extension uses the reviewed desktop navigation from November 15, 2026. It includes 21 top-level destinations and publicly exposed child links. Cinema Studio’s Projects shortcut opens the studio and focuses the native Search projects control when it is visible. Community’s public Projects gallery has its own direct link. Sign-in and sign-up remain in the site's own UI. The API link goes to Higgsfield’s API domain, where the extension does not inject a sidebar.

To discover feature links, open a Higgsfield page and choose **Scan Navigation** from the extension popup. Chrome must allow Custom Nav to access that tab. You can use your existing Higgsfield session when scanning feature menus available only after signing in. The scan checks supported navigation menus on the current page. It does not visit other pages, open content collections, or collect projects, files, assets, chats, or account details.

**Last Scanned** updates after a completed scan, including when it finds no new links. Review the proposed additions grouped by section, then choose **Save Links** or **Discard**. Discarding keeps the existing links. Custom Nav stores approved links and preferences locally and never scans automatically. **Clear Saved Navigation** removes approved additions and the scan timestamp after confirmation. The bundled links remain available.

## Extending to other sites

- `sites/higgsfield.js` defines the site adapter, reviewed public destinations, and native style hooks. A new adapter can share the renderer and storage code with its own explicit host matches.
- `navigation.js` loads the bundled catalog and applies approved additions from local storage.
- `discovery.js` validates static feature routes and merges approved additions under their parent sections. `scan-page.js` reads the site adapter’s allowed menus in response to a popup scan request.
- `sidebar.js` renders navigation and handles keyboard, resize, and preference changes.
