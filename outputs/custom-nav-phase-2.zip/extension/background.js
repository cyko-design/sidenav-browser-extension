importScripts("sites/higgsfield.js", "navigation.js", "discovery.js");

chrome.runtime.onMessage.addListener((message, sender, reply) => {
  if (message?.type !== "clear-navigation" || sender.id !== chrome.runtime.id
      || sender.url !== chrome.runtime.getURL("popup.html")) return;

  const site = navSites.find(candidate => candidate.id === message.site);
  if (!site) return;

  // Complete a confirmed clear even if the popup closes before storage responds.
  navigator.locks.request(navigationLockName(site), async () => {
    const keys = [navigationKey(site), scanTimeKey(site)];
    const links = await readSavedLinks(site);
    await chrome.storage.local.remove(keys);
    const remaining = await chrome.storage.local.get(keys);
    if (keys.some(key => Object.hasOwn(remaining, key))) throw new Error("Saved navigation is still present.");
    return { removed: links.length };
  }).then(reply, () => reply({ error: "Couldn’t clear saved navigation." }));

  return true;
});
